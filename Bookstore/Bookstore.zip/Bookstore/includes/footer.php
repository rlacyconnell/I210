</div>
<div id="footer">
    <hr width="95%" />
    &copy <?php echo date("Y") ?> PHP Online Bookstore. All Rights Reserved.
</div>
</div>

</body>
</html>